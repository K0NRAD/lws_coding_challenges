/*
Römische Zahlen

Konvertiert römische Zahlen in arabische Zahlen. Die Testfälle sind in der Datei challenge.test.js, alle Tests 
enthalten valide römische Zahlen, dh. alle römischen Zahlen sind korrekt formatiert und entsprechen den Regeln.

Beispiele:
    convertire("I")         ➞ 1
    convertire("V")         ➞ 5
    convertire("IX")        ➞ 9
    convertire("X")         ➞ 10
    convertire("XL")        ➞ 40
    convertire("MMMCMXCIX") ➞ 3999 // das ist die Maximalzahl die mit römischen Zahlen dargestellt werden kann

Mapping der römischen Zahlen zu den arabischen Zahlen:    
     I:1, IV:4, V:5, IX:9, X:10, XL:40, L:50, XC:90, C:100, CD:400, D:500, CM:900, M:1000  

Regeln für valide römische Zahlen:

- Nur bestimmte Subtraktionskombinationen sind erlaubt.
        IV = 4   ➞ (5 - 1)
        IX = 9   ➞ (10 - 1)
        XL = 40  ➞ (50 - 10)
        XC = 90  ➞ (100 - 10)
        CD = 400 ➞ (500 - 100)
        CM = 900 ➞ (1000 - 100)
- Ein kleineres Symbol darf nur vor einem größeren stehen, nicht umgekehrt (außer bei Addition).
- V, L, und D dürfen nicht wiederholt werden.
- I, X, C und M dürfen maximal dreimal wiederholt werden.
- Die Reihenfolge der Symbole ist wichtig (Addition oder Subtraktion).
- Die Zahl muss so kurz wie möglich geschrieben werden, keine unnötigen Wiederholungen, wenn es 
  eine Subtraktionsmöglichkeit gibt.    

Testen:
    npm test ./003_roemischezahlen    
*/

function convertire(number) {

    return 0;
}

module.exports = {
    convertire,
};

// ====================================================================================================
// maueller Test ausführen mit 'node ./003_roemischezahlen/challenge.js'
const arabicNumber = convertire("MMMCMXCIX");
console.log(arabicNumber); // Erwartete Ausgabe: 3999