/*
Goldene Mitte

Von einem Wort sollst du den mittleren Buchstaben raussuchen. Wenn es aber ein Wort mit gerader Anzahl 
Buchstaben ist, dann gibt's ja keinen einen mittleren, sondern zwei. Dann nimmst du die beiden."

Beispiele:
    goldeneMitte("Lehrwerkstatt")   ➞ "r"
    goldeneMitte("JavaScript")      ➞ "Sc"
    goldeneMitte("Kaffee")          ➞ "ff"
    goldeneMitte("Hallo")           ➞ "l"

Testen:
    npm test ./002_goldene_mitte    
*/
function goldenMiddle(word) {
    return "";
}

module.exports = {
    goldenMiddle,
};

// ====================================================================================================
// maueller Test ausführen mit 'node ./002_goldene_mitte/challenge.js'

const result = goldenMiddle("Lehrwerkstatt");
if (result !== "r") {
    console.error(`Test nicht bestanden! Erwartet: 'r' aber erhalten: ${result}`);
} else {
    console.log("Test bestanden:", result); // Erwartete Ausgabe: "r"
}
