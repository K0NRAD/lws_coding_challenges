const { goldenMiddle } = require("./challenge");

describe("Goldene Mitte", () => {
    test("Gibt den mittleren Buchstaben zurück", () => {
        expect(goldenMiddle("Lehrwerkstatt")).toBe("r");
        expect(goldenMiddle("JavaScript")).toBe("Sc");
        expect(goldenMiddle("Kaffee")).toBe("ff");
        expect(goldenMiddle("Hallo")).toBe("l");
    });
});
