package isp_bad

interface Robot {
    fun move(): String
    fun speak(): String
    fun grab(): String
    fun fly(): String
    fun swim(): String
}

// MovementRobot kann sich bewegen, sprechen und greifen, aber nicht fliegen oder schwimmen
// Muss trotzdem alle Methoden implementieren
class MovementRobot : Robot {
    override fun move(): String = "Bewegt sich auf Rädern"
    override fun speak(): String = "Gibt Pieptöne von sich"
    override fun grab(): String = "Greift Objekt mit mechanischem Arm"

    // Problematische Implementierungen, die nicht unterstützt werden
    override fun fly(): String = throw UnsupportedOperationException("Dieser Roboter kann nicht fliegen")
    override fun swim(): String = throw UnsupportedOperationException("Dieser Roboter kann nicht schwimmen")
}

// FlyingRobot kann sich bewegen, sprechen, greifen und fliegen, aber nicht schwimmen
// Muss trotzdem alle Methoden implementieren
class FlyingRobot : Robot {
    override fun move(): String = "Bewegt sich mit Propellern"
    override fun speak(): String = "Gibt Summgeräusche von sich"
    override fun grab(): String = "Greift Objekt mit Magnetgreifer"
    override fun fly(): String = "Fliegt durch die Luft"

    // Problematisch, nicht unterstützt
    override fun swim(): String = throw UnsupportedOperationException("Dieser Roboter kann nicht schwimmen")
}

// SwimmingRobot kann sich bewegen, sprechen, greifen und schwimmen, aber nicht fliegen
// Muss trotzdem alle Methoden implementieren
class SwimmingRobot : Robot {
    override fun move(): String = "Bewegt sich mit Propellern"
    override fun speak(): String = "Gibt Summgeräusche von sich"
    override fun grab(): String = "Greift Objekt mit Magnetgreifer"
    override fun swim(): String = "Schwimmt im Wasser"

    // Problematisch, nicht unterstützt
    override fun fly(): String = throw UnsupportedOperationException("Dieser Roboter kann nicht fliegen")
}

// Verwenden der Roboter - potenziell gefährlich
fun useRobot(robot: Robot) {
    println(robot.move())
    println(robot.speak())
    println(robot.grab())

    try {
        println(robot.fly())
    } catch (e: UnsupportedOperationException) {
        println("Warnung: ${e.message}")
    }

    try {
        println(robot.swim())
    } catch (e: UnsupportedOperationException) {
        println("Warnung: ${e.message}")
    }
}

fun main() {
    useRobot(MovementRobot())
    useRobot(FlyingRobot())
    useRobot(SwimmingRobot())
}