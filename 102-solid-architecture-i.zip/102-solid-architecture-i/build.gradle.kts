plugins {
    kotlin("jvm") version "2.1.10"
}

group = "schwarz.it.lws"
version = "1.0-SNAPSHOT"

repositories {
    mavenCentral()
}

dependencies {
    // Kotest für testgetriebene Entwicklung
    testImplementation("io.kotest:kotest-runner-junit5:5.5.5")
    testImplementation("io.kotest:kotest-assertions-core:5.5.5")
    testImplementation("io.kotest:kotest-property:5.5.5")
    testImplementation("io.kotest:kotest-framework-api:5.5.5")
    testImplementation("io.kotest:kotest-framework-engine:5.5.5")
    // MockK für Mocking in Tests
    testImplementation("io.mockk:mockk:1.13.17")

}

tasks.test {
    useJUnitPlatform()
}
kotlin {
    jvmToolchain(21)
}