/*

Bit-Zaehlen

In der Welt der Computer sind Bits die grundlegenden Bausteine der Information. Manchmal müssen wir tief in die 
binäre Darstellung von Zahlen eintauchen und herausfinden, wie viele "1en" (gesetzte Bits) sie enthalten.

Schreibe eine Funktion namens countBits(n), die eine nicht-negative Ganzzahl n als Eingabe akzeptiert und die 
Anzahl der in ihrer binären Darstellung gesetzten Bits (d.h. die Anzahl der Einsen) zurückgibt.

Wichtig: Die Umwandlung in ein String mithilfe der eingebauten Funktion von JavaScript, ist nicht erlaubt.

Beispiele:

Für n = 0 sollte countBits(0) den Wert 0 zurückgeben, da die binäre Darstellung von 0 nur aus Nullen besteht.

Für n = 5 sollte countBits(5) den Wert 2 zurückgeben, da die binäre Darstellung von 5 101 ist und zwei Einsen enthält.

Für n = 9 sollte countBits(9) den Wert 2 zurückgeben, da die binäre Darstellung von 9 1001 ist und zwei Einsen enthält.

Für n = 12 sollte countBits(12) den Wert 2 zurückgeben, da die binäre Darstellung von 12 1100 ist und zwei Einsen enthält.

Hinweise:

- Denke darüber nach, wie die binäre Darstellung einer Zahl Schritt für Schritt untersucht werden kann.
- Bitweise Operatoren könnten hier sehr nützlich sein! (Besonders & und >>)

Testen:
    npm test ./006_bit_zaehlen 
*/

function countBits(n) {
    return -1;
}

module.exports = {
    countBits,
};
// ====================================================================================================
// maueller Test ausführen mit 'node ./006_bit_zaehlen/challenge.js

const number = 4567;
const countOfBits = countBits(number); //).toBe(8); // Binär: 1000111010111
if (countOfBits !== 8) {
    console.error(`Test nicht bestanden: die Zahl 4567 enthält 8 und nicht ${countOfBits} gesetzte Bits. Binär: 1000111010111.`);
} else {
    console.log(`Test bestanden: die Zahl 4567 entspricht binär: 1000111010111 und enthält 8 gesetzte Bits. `);
}
