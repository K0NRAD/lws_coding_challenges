const { countBits } = require("./challenge");

describe("Bitcounting Tests", () => {
    it("0 Bits in 0", () => {
        expect(countBits(0)).toBe(0);
    });

    it("Zahl mit 3 gesetzten Bits", () => {
        expect(countBits(7)).toBe(3); // Binär: 111
    });

    it("Zahl mit 2 gesetzten Bits", () => {
        expect(countBits(17)).toBe(2); // Binär: 10001
    });

    it("Zahl mit 3 gesetzten Bits", () => {
        expect(countBits(56)).toBe(3); // Binär: 111000
    });

    it("Zahl mit 8 gesetzten Bits", () => {
        expect(countBits(9999)).toBe(8); // Binär: 10011100001111
    });

    it("Zahl mit 5 gesetzten Bits", () => {
        expect(countBits(10000)).toBe(5); // Binär: 10011100010000
    });

    it("Zahl mit 8 gesetzten Bits", () => {
        expect(countBits(4567)).toBe(8); // Binär: 1000111010111
    });

    it("Zahl mit 5 gesetzten Bits", () => {
        expect(countBits(1234)).toBe(5); // Binär: 10011010010
    });

    it("Zahl mit 9 gesetzten Bits", () => {
        expect(countBits(511)).toBe(9); // Binär: 111111111
    });

    it("Zahl mit einem gesetzten Bit am Anfang", () => {
        expect(countBits(1024)).toBe(1); // Binär: 10000000000
    });
});
