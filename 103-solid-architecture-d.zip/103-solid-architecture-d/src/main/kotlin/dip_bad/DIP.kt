package dip_bad

// SCHLECHTE IMPLEMENTIERUNG - VERSTÖSST GEGEN DIP
// -------------------------------------------------

// Konkrete Implementierung einer Datenbank
class MySQLDatabase {
    fun connect(): String = "Verbindung zur MySQL-Datenbank hergestellt"
    fun executeQuery(query: String): String = "MySQL-Abfrage ausgeführt: $query"
    fun disconnect(): String = "Verbindung zur MySQL-Datenbank getrennt"
}

// UserService abhängig von einer konkreten Implementierung
class UserService {
    private val database = MySQLDatabase()

    fun getUserData(userId: String): String {
        database.connect()
        val result = database.executeQuery("SELECT * FROM users WHERE id = $userId")
        database.disconnect()
        return result
    }
}

// Verwendung des Services
fun useUserService() {
    val userService = UserService()
    println(userService.getUserData("12345"))

    // Was, wenn wir zu PostgreSQL wechseln wollen?
    // Wir müssten den gesamten UserService ändern!
}

fun main() {
    useUserService()
}

