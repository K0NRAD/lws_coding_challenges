/*
10 Minuten Spaziergang

Du nimmst an einem Spaziergang teil, der genau zehn Minuten dauern soll. Du startest von einem bestimmten 
Punkt und musst nach genau zehn Minuten wieder zu diesem Ausgangspunkt zurückkehren.

Du erhältst ein Array walk, das die Richtung deiner Schritte darstellt. Jedes Element des Arrays ist ein 
einzelner Buchstaben, der eine Himmelsrichtung repräsentiert:

'n' (North = Norden)
's' (South = Süden)
'e' (East  = Osten)
'w' (West  = Westen)

Jeder dieser Schritte dauert genau eine Minute.

Deine Aufgabe ist es, eine Funktion isValidWalk(walk) zu schreiben, die true zurückgibt, wenn der Spaziergang 
genau zehn Minuten dauert und dich zum Ausgangspunkt zurückbringt, und false in allen anderen Fällen.

Beispiel:

isValidWalk(['n', 's', 'n', 's', 'n', 's', 'n', 's', 'n', 's']) 
    sollte true zurückgeben (zehn Minuten und Rückkehr zum Ausgangspunkt).

isValidWalk(['w', 'e', 'w', 'e', 'w', 'e', 'w', 'e', 'w', 'e', 'w', 'e']) 
    sollte false zurückgeben (dauert länger als zehn Minuten).

isValidWalk(['w', 's']) 
    sollte false zurückgeben (dauert weniger als zehn Minuten und kehrt nicht zum Ausgangspunkt zurück).

isValidWalk(['n', 'n', 'n', 's', 'n', 's', 'n', 's', 'n', 's']) 
    sollte false zurückgeben (zehn Minuten aber keine Rückkehr zum Ausgangspunkt).

isValidWalk(['n', 'e', 'n', 'w', 's', 's', 's', 'w', 'n', 'n', 'e', 's']) 
    sollte true zurückgeben (dauert zwar länger als zehn Minuten, wird aber in den Tests mit true validiert).

Hinweise:

- Die Funktion isValidWalk muss als Parameter ein Array walk entgegennehmen.
- Die Funktion muss einen Booleschen Wert (true oder false) zurückgeben.
- Der Ausgangspunkt hat die Koordinaten (0, 0).
- Du kannst die x-Koordinate nutzen, um die Nord-Süd-Bewegung zu verfolgen.
- Du kannst die y-Koordinate nutzen, um die Ost-West-Bewegung zu verfolgen.
- Die Länge des Arrays walk muss genau 10 sein.
- Die Endkoordinaten müssen (0, 0) sein.

*/

function isValidWalk(walk) {
    return false;
}

module.exports = {
    isValidWalk,
};

// ====================================================================================================
// maueller Test ausführen mit 'node ./004_10_minuten_spaziergang/challenge.js'
const result = isValidWalk(["w", "e", "w", "e", "w", "e", "w", "e", "w", "e"]);
if(result === false) {
    console.Error("Test nicht bestanden! Erwartet: true aber erhalten: false");
} else {
    console.log("Test bestanden:", result); // Erwartete Ausgabe: true
}
