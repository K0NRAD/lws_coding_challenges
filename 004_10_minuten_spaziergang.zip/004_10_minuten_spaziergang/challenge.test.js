const { isValidWalk } = require("./challenge");

describe("Zehn-Minuten-Spaziergang", () => {
    it("Sollte true zurückgeben, wenn der Spaziergang 10 Minuten dauert und zum Ausgangspunkt zurückkehrt", () => {
        expect(isValidWalk(["n", "s", "n", "s", "n", "s", "n", "s", "n", "s"])).toBe(true);
    });

    it("Sollte true zurückgeben, wenn der Spaziergang 10 Minuten dauert und zum Ausgangspunkt zurückkehrt (anderes Beispiel)", () => {
        expect(isValidWalk(["w", "e", "w", "e", "w", "e", "w", "e", "w", "e"])).toBe(true);
    });

    it("Sollte false zurückgeben, wenn der Spaziergang weniger als 10 Minuten dauert", () => {
        expect(isValidWalk(["w", "s"])).toBe(false);
    });

    it("Sollte false zurückgeben, wenn der Spaziergang mehr als 10 Minuten dauert", () => {
        expect(isValidWalk(["n", "s", "n", "s", "n", "s", "n", "s", "n", "s", "n", "s"])).toBe(false);
    });

    it("Sollte false zurückgeben, wenn der Spaziergang 10 Minuten dauert, aber nicht zum Ausgangspunkt zurückkehrt", () => {
        expect(isValidWalk(["n", "n", "n", "s", "n", "s", "n", "s", "n", "s"])).toBe(false);
    });

    it("Sollte false zurückgeben, wenn der Spaziergang leer ist", () => {
        expect(isValidWalk([])).toBe(false); // Leer ist nicht 10 Minuten
    });

    it("Sollte false zurückgeben, wenn es nur einen Schritt gibt", () => {
        expect(isValidWalk(["n"])).toBe(false); // Nur ein Schritt ist nicht 10 Minuten
    });

    it("Sollte false zurückgeben, wenn alle Schritte in die gleiche Richtung gehen", () => {
        expect(isValidWalk(["n", "n", "n", "n", "n", "n", "n", "n", "n", "n"])).toBe(false);
    });

    it("Sollte false zurückgeben, wenn der Spaziergang ungültige Richtungen enthält", () => {
        // In der Aufgabenstellung nicht definiert, daher ignorieren wir ungültige Richtungen
        // und behandeln sie, als ob sie nicht da wären (oder werfen einen Fehler, je nach Anforderung).
        // Hier wird gezeigt, dass die Funktion robust gegenüber unerwarteten Eingaben sein sollte.
        // Diese Tests können je nach gewünschtem Verhalten angepasst werden.
        expect(isValidWalk(["n", "s", "n", "s", "n", "s", "n", "s", "n", "x"])).toBe(false);
    });

    it("Sollte false zurückgeben, wenn die Anzahl der Schritte zwar stimmt, aber man nicht zum Ausgangspunkt zurückkehrt", () => {
        expect(isValidWalk(["n", "n", "n", "s", "s", "n", "w", "e", "w", "e"])).toBe(false);
    });
});
