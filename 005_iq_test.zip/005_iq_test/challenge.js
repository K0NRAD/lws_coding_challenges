/*
IQ-Test

Peter möchte herausfinden, wer in seiner Klasse am intelligentesten ist. Er hat einen IQ-Test entwickelt! 
Der Test besteht aus einer Reihe von Zahlen. Peter hat festgestellt, dass alle Zahlen im Test mit einer 
Ausnahme entweder gerade oder ungerade sind.

Deine Aufgabe ist es, eine Funktion iqTest(numbers) zu schreiben, die eine Zeichenkette von Zahlen als 
Eingabe erhält (durch Leerzeichen getrennt) und die Position derjenigen Zahl zurückgibt, die sich von den 
anderen unterscheidet (also entweder die einzige ungerade oder die einzige gerade Zahl).

Beispiel:

iqTest("2 4 7 8 10") => 3 (Die dritte Zahl '7' ist ungerade, während alle anderen gerade sind)

iqTest("1 2 1 1") => 2 (Die zweite Zahl '2' ist gerade, während alle anderen ungerade sind)

Hinweise:

- Die Position der Zahlen beginnt bei 1 (nicht bei 0).
- Die übergebene Zeichenkette enthält immer mindestens drei Zahlen.
- Es wird immer genau eine Zahl geben, die sich von den anderen unterscheidet.

Testen:
    npm test ./005_iq_test  
*/

function iqTest(numbers) {
    return -1;
}

module.exports = {
    iqTest,
};

// ====================================================================================================
// maueller Test ausführen mit 'node ./005_iq_test/challenge.js'

const numbers = "96 58 92 60 10 90 44 58 8 86 24 60 14 82 79 80 62 94 58 70 12 26 38 84 90 2 86 94 54 84 44";
const oddNumberPosition = iqTest(numbers)
if (oddNumberPosition !== 15) {
    console.error("Test nicht bestanden, die ungerade Zahl 79 ist an Position 15.")    
} else {
    console.log(`Test bestanden: die ungerade Zahl 79 ist an Position ${oddNumberPosition}`)
}

