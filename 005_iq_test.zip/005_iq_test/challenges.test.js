const { iqTest } = require("./challenge");

describe("iqTest - Tests", () => {
    it("should work with a array (5 numbers) - unique is odd", () => {
        const numbers = "11 20 22 24 26";
        expect(iqTest(numbers)).toBe(1); // 11 is the unique odd at position 1
    });

    it("should work with a array (5 numbers) - unique is even", () => {
        const numbers = "1 3 5 7 10";
        expect(iqTest(numbers)).toBe(5); // 10 is the unique even at position 5
    });

    it("should work with a array (15 numbers) - unique is odd", () => {
        const numbers = "2 4 6 8 10 12 14 15 16 18 20 22 24 26 28";
        expect(iqTest(numbers)).toBe(8); // 15 is the unique odd at position 8
    });

    it("should work with a array (20 numbers) - unique is odd", () => {
        const numbers = "56 88 28 66 36 74 60 26 32 82 72 64 20 92 36 77 90 2 22 56 90";
        expect(iqTest(numbers)).toBe(16); // 77 is the unique odd at position 16
    });

    it("should work with a array (30 numbers) - unique is even", () => {
        const numbers = "69 31 83 61 15 84 13 23 49 73 57 99 85 49 33 15 29 71 47 15 85";
        expect(iqTest(numbers)).toBe(6); // 84 is the unique even at position 15
    });

    it("should work with a array (30 numbers) - unique is even", () => {
        const numbers = "33 57 83 55 19 71 41 75 21 41 69 4 33 79 27 27 7 19 87 63 9 3 69 15 23 21 49 77 81 11 47";
        expect(iqTest(numbers)).toBe(12); // 4 is the unique even at position 12
    });

    it("should work with a array (40 numbers) - unique is odd", () => {
        const numbers = "20 52 24 100 26 36 76 33 10 20 22 72 26 6 18 82 34 22 96 38 28 74 58 54 22 64 98 38 78 60 70 10 48 18 94 16 28 54 16 24 32";
        expect(iqTest(numbers)).toBe(8); // 33 is the unique odd at position 8
    });

    it("should work with a array (50 numbers) - unique is even", () => {
        const numbers = "15 57 53 97 95 91 59 99 63 95 3 85 71 37 11 55 49 9 25 7 53 51 1 43 15 93 55 33 19 33 79 1 11 65 75 15 75 37 97 33 5 29 91 23 49 47 36 15 9 99 67";
        expect(iqTest(numbers)).toBe(47); // 36 is the unique even at position 47
    });

});
