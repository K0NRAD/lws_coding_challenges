/*
Rabatt Rechner für Online-Shop

Du arbeitest für einen Online-Shop und bist für die Implementierung des Rabattsystems zuständig. 
Das Rabattsystem basiert auf verschiedenen Regeln, die kombiniert werden können.

Es gibt zwei Funktionen, die du implementieren sollst:

- berechneRabatt(bestellung): Diese Funktion berechnet die Rabattinformationen basierend auf den Bestellungsdetails.
- berechneRabattiertenPreis(bestellung): Diese Funktion berechnet den endgültigen, rabattierten Preis einer Bestellung.

Details zu den Rabattregeln:

Der Shop bietet folgende Rabatte an:

- Mengenrabatt: Wenn der gesamtbetrag der Bestellung über 100€ liegt, gibt es 10% Rabatt auf den Gesamtbetrag.
- Artikelanzahl-Rabatt: Wenn die Bestellung 3 oder mehr artikel enthält, gibt es 5% Rabatt auf den Gesamtbetrag.
- Haupt-Rabatt: Es wird der höhere Rabatt aus Mengenrabatt und Artikelanzahl-Rabatt angewendet.
- Neukundenrabatt: Neukunden (istNeukunde === true) erhalten 15% Rabatt auf den ersten Artikel in der Bestellung.
- Treuerabatt: Bestandskunden (istNeukunde === false) mit mehr als 5 anzahlVorbestellungen erhalten 7% Rabatt auf den Gesamtbetrag.

Input (Bestellungs-Objekt):

Die Funktionen nehmen ein bestellung-Objekt als Parameter entgegen. Das Objekt hat folgende Struktur:

{
  gesamtbetrag: number,         // Gesamtbetrag der Bestellung
  artikel: number[],            // Array der Artikelpreise
  istNeukunde: boolean,         // True, wenn der Kunde ein Neukunde ist, sonst false
  anzahlVorbestellungen: number // Anzahl der vorherigen Bestellungen des Kunden
}    

Aufgabe:

1.) Implementiere die Funktion 'berechneRabatt(bestellung)':

Die Funktion soll ein Objekt mit folgenden Eigenschaften zurückgeben:

{
    rabattProzent: number,      // Gesamt-Rabatt in Prozent
    rabattBetrag: number,       // Gesamt-Rabatt in Euro
    rabattDetails: [{           // Array von Rabattdetails
        beschreibung: string,   // Beschreibung des Rabatts
        prozent: number,        // Rabatt in Prozent (falls zutreffend)
        betrag: number          // Rabatt in Euro
    }]
}

'rabattDetails' soll ein Array von Objekten sein, wobei jedes Objekt die Beschreibung, 
den Prozentsatz und den Betrag jedes angewendeten Rabatts enthält.

Sollte kein Rabatt anwendbar sein, so soll 'rabattProzent' und 'rabattBetrag' auf 0 gesetzt 
und 'rabattDetails' ein leeres Array sein.

2.) Implementiere die Funktion 'berechneRabattiertenPreis(bestellung)':

Die Funktion soll ein Objekt mit folgenden Eigenschaften zurückgeben:

{
    ursprungsbetrag: number,    // Ursprünglicher Gesamtbetrag der Bestellung
    rabattbetrag: number,       // Gesamt-Rabatt in Euro (maximal der Ursprungsbetrag)
    endpreis: number,           // Endgültiger, rabattierter Preis
    rabattDetails: [{           // Array von Rabattdetails (aus berechneRabatt)
        beschreibung: string,   // Beschreibung des Rabatts
        prozent: number,        // Rabatt in Prozent (falls zutreffend)
        betrag: number          // Rabatt in Euro
    }]
}
Der 'rabattbetrag' soll nicht höher sein als der 'ursprungsbetrag'. 'rabattDetails' soll das 
gleiche Array von 'rabattDetails' wie von der Funktion 'berechneRabatt' zurückgegeben werden.

--- ---

Entwicklungsumgebung:
    Visual Studio Code installieren - https://code.visualstudio.com
    Node.js installieren            - https://nodejs.org

    npm init -y
    npm install jest -D

Settings (package.json):
    {
      ...
      "scripts": {
        "test": "jest",
        "test:watch": "jest --watch"
      },
      ...
    }

Testen:
    npm test ./001_rabatt_rechner    
*/
function berechneRabatt(bestellung) {
    return {
        rabattProzent: 0,
        rabattBetrag: 0,
        rabattDetails: [],
    };
}

function berechneRabattiertenPreis(bestellung) {
    return {
        ursprungsbetrag: 0,
        rabattbetrag: 0,
        endpreis: 0,
        rabattDetails: [],
    };
}

module.exports = {
    berechneRabatt,
    berechneRabattiertenPreis,
};

// ====================================================================================================
// maueller Test ausführen mit 'node ./001_rabatt_rechner/challenge.js'
const bestellung = {
    gesamtbetrag: 120,
    artikel: [50, 30, 40],
    istNeukunde: true,
    anzahlVorbestellungen: 0,
};

const requieredRabattierterPreis = {
    ursprungsbetrag: 120,
    rabattbetrag: 19.5,
    endpreis: 100.5,
    rabattDetails: [
        { beschreibung: "Mengenrabatt (Bestellung über 100€)", prozent: 10, betrag: 12 },
        { beschreibung: "Neukundenrabatt (15% auf den ersten Artikel)", prozent: 15, betrag: 7.5 },
    ],
};

const rabattierterPreis = berechneRabattiertenPreis(bestellung);
if (JSON.stringify(rabattierterPreis) !== JSON.stringify(requieredRabattierterPreis)) {
    console.error(`Test nicht bestanden! \nErwartet: ${JSON.stringify(requieredRabattierterPreis, null, 2)} \nErhalten: ${JSON.stringify(rabattierterPreis, null, 2)}`);
} else {
    JSON.stringify(rabattierterPreis, null, 2);
}
