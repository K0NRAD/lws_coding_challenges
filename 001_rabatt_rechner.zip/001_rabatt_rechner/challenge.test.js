const { berechneRabatt, berechneRabattiertenPreis } = require("./challenge");

describe("Rabattrechner", () => {
    test("Berechnet keinen Rabatt für kleine Bestellungen", () => {
        const bestellung = {
            gesamtbetrag: 50,
            artikel: [20, 30],
            istNeukunde: false,
            anzahlVorbestellungen: 2,
        };

        const ergebnis = berechneRabatt(bestellung);

        expect(ergebnis.rabattBetrag).toBe(0);
        expect(ergebnis.rabattDetails.length).toBe(0);
    });

    test("Berechnet 10% Rabatt für Bestellungen über 100€", () => {
        const bestellung = {
            gesamtbetrag: 120,
            artikel: [40, 80],
            istNeukunde: false,
            anzahlVorbestellungen: 2,
        };

        const ergebnis = berechneRabatt(bestellung);

        expect(ergebnis.rabattBetrag).toBeCloseTo(12); // 10% von 120€
        expect(ergebnis.rabattDetails.length).toBe(1);
        expect(ergebnis.rabattDetails[0].prozent).toBe(10);
    });

    test("Berechnet 10% Rabatt für Bestellungen über 100€, für Neukunden", () => {
        const bestellung = {
            gesamtbetrag: 120,
            artikel: [40, 80],
            istNeukunde: true,
            anzahlVorbestellungen: 0,
        };

        const ergebnis = berechneRabatt(bestellung);
        expect(ergebnis.rabattBetrag).toBeCloseTo(18); // 10% von 120€ + 15% von 40€ (Neukundenrabatt 1. Artikel)
        expect(ergebnis.rabattDetails.length).toBe(2);
        expect(ergebnis.rabattDetails[0].prozent).toBe(10);
    });

    test("Berechne Rabatt für Bestellung unter 100€ für Neukunden mit 3 Artikeln", () => {
        const bestellung = {
            gesamtbetrag: 99,
            artikel: [50, 30, 40],
            istNeukunde: true,
            anzahlVorbestellungen: 0,
        };

        const ergebnis = berechneRabattiertenPreis(bestellung);

        expect(ergebnis.rabattbetrag).toBeCloseTo(12.45); // 5% von 99€ + 15% von 50€ (Neukundenrabatt 1. Artikel)
        expect(ergebnis.rabattDetails.length).toBe(2);
        expect(ergebnis.endpreis).toBeCloseTo(86.55);
        expect(ergebnis.rabattDetails[0].prozent).toBe(5);
        expect(ergebnis.rabattDetails[0].betrag).toBeCloseTo(4.95);
        expect(ergebnis.rabattDetails[1].prozent).toBe(15);
        expect(ergebnis.rabattDetails[1].betrag).toBeCloseTo(7.5);
    });

    test("Berechne Rabatt für Bestellung über 100€ für Bestandskunden mit mehr als 5 Artikel ", () => {
        const bestellung = {
            gesamtbetrag: 123,
            artikel: [50, 30, 40, 50, 30, 40, 50],
            istNeukunde: false,
            anzahlVorbestellungen: 6,
        };

        const ergebnis = berechneRabattiertenPreis(bestellung);

        expect(ergebnis.rabattbetrag).toBeCloseTo(20.91); // 10% von 123€ + 7% von 123€ (Treuerabatt)
        expect(ergebnis.rabattDetails.length).toBe(2);
        expect(ergebnis.endpreis).toBeCloseTo(102.09);
        expect(ergebnis.rabattDetails[0].prozent).toBe(10);
        expect(ergebnis.rabattDetails[0].betrag).toBeCloseTo(12.3);
        expect(ergebnis.rabattDetails[1].prozent).toBe(7);
        expect(ergebnis.rabattDetails[1].betrag).toBeCloseTo(8.61);
    });
});
