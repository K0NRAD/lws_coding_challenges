package schwarz.it.lws

import kotlin.math.sqrt

class AreaCalculator {
    fun calculateArea(shape: Any): Double {
        return when (shape) {
            is Hexagon -> calculateHexagonArea(shape)
            is Circle -> calculateCircleArea(shape)
            is Triangle -> calculateTriangleArea(shape)
            else -> 0.0
        }
    }

    fun calculateHexagonArea(hexagon: Hexagon): Double {
        val width = hexagon.width
        return 6.0 * (sqrt(3.0) / 4.0) * (width * width)
    }

    fun calculateCircleArea(shape: Circle): Double {
        val radius = shape.radius
        return radius * radius * Math.PI
    }

    fun calculateTriangleArea(triangle: Triangle): Double {
        val width = triangle.width
        val height = triangle.height
        return width * height / 2.0
    }

}

class Rectangle(val width: Double, val height: Double) {
    fun getName(): String = "Rectangle($width, $height)"
}

class Circle(val radius: Double) {
    fun getName(): String = "Circle($radius)"
}

class Triangle(val width: Double, val height: Double) {
    fun getName(): String = "Triangle($width, $height)"
}

class Hexagon(val width: Double) {
    fun getName(): String = "Hexagon($width)"
}

fun main() {
    val areaHexagon = AreaCalculator().calculateArea(Hexagon(4.0))
    println("Area Hexagon: $areaHexagon")

    val areaCircle = AreaCalculator().calculateArea(Circle(4.0))
    println("Area Circle: $areaCircle")

    val areaTriangle = AreaCalculator().calculateArea(Triangle(4.0, 8.0))
    println("Area Triangle: $areaTriangle")
}